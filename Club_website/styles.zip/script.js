// Home page: Change background color of event title on hover
const eventTitle = document.getElementById('event-title');
eventTitle.addEventListener('mouseover', function() {
  eventTitle.style.backgroundColor = '#f0e68c'; // Hover effect
});
eventTitle.addEventListener('mouseout', function() {
  eventTitle.style.backgroundColor = ''; // Reset
});

// Registration page: Show alert on form submission
document.getElementById('registration-form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevents form from refreshing the page
  alert('Registration Successful!');
});
